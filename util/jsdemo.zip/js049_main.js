//window.open('url 경로', '창이름', '옵션')

window.open(
  'js049_popup.html', 
  '', 
  'width=500, height=500, scrollbars=no, toolbars=no, location=no'
);